package com.example.ocms.service;

import com.example.ocms.model.Enrollment;
import com.example.ocms.repository.EnrollmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;

    public EnrollmentService(EnrollmentRepository enrollmentRepository) {
        this.enrollmentRepository = enrollmentRepository;
    }

    public Enrollment createEnrollment(Enrollment enrollment) {
        return enrollmentRepository.save(enrollment);
    }

    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepository.findAll();
    }

    public Optional<Enrollment> getEnrollmentById(Long id) {
        return enrollmentRepository.findById(id);
    }

    public Enrollment updateEnrollment(Long id, Enrollment enrollment) {
        Optional<Enrollment> existingEnrollment =
                enrollmentRepository.findById(id);

        if (existingEnrollment.isPresent()) {
            Enrollment updatedEnrollment = existingEnrollment.get();

            updatedEnrollment.setStudentId(enrollment.getStudentId());
            updatedEnrollment.setCourseId(enrollment.getCourseId());
            updatedEnrollment.setEnrollmentDate(enrollment.getEnrollmentDate());
            updatedEnrollment.setStatus(enrollment.getStatus());

            return enrollmentRepository.save(updatedEnrollment);
        }

        return null;
    }

    public void deleteEnrollment(Long id) {
        enrollmentRepository.deleteById(id);
    }
}