package com.example.ocms.service;

import com.example.ocms.model.CourseContent;
import com.example.ocms.repository.CourseContentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseContentService {

    private final CourseContentRepository courseContentRepository;

    public CourseContentService(CourseContentRepository courseContentRepository) {
        this.courseContentRepository = courseContentRepository;
    }

    public CourseContent createContent(CourseContent content) {
        return courseContentRepository.save(content);
    }

    public List<CourseContent> getAllContent() {
        return courseContentRepository.findAll();
    }

    public Optional<CourseContent> getContentById(Long id) {
        return courseContentRepository.findById(id);
    }

    public CourseContent updateContent(Long id, CourseContent content) {
        Optional<CourseContent> existingContent = courseContentRepository.findById(id);

        if (existingContent.isPresent()) {
            CourseContent updatedContent = existingContent.get();

            updatedContent.setCourseId(content.getCourseId());
            updatedContent.setTitle(content.getTitle());
            updatedContent.setContentType(content.getContentType());
            updatedContent.setContentUrl(content.getContentUrl());

            return courseContentRepository.save(updatedContent);
        }

        return null;
    }

    public void deleteContent(Long id) {
        courseContentRepository.deleteById(id);
    }
}