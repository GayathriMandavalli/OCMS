package com.example.ocms.service;

import com.example.ocms.model.Notification;
import com.example.ocms.repository.NotificationRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    public Notification createNotification(Notification notification) {
        return notificationRepository.save(notification);
    }

    public List<Notification> getAllNotifications() {
        return notificationRepository.findAll();
    }

    public Optional<Notification> getNotificationById(Long id) {
        return notificationRepository.findById(id);
    }

    public Notification updateNotification(Long id, Notification notification) {
        Optional<Notification> existingNotification =
                notificationRepository.findById(id);

        if (existingNotification.isPresent()) {
            Notification updatedNotification = existingNotification.get();

            updatedNotification.setUserId(notification.getUserId());
            updatedNotification.setMessage(notification.getMessage());
            updatedNotification.setType(notification.getType());
            updatedNotification.setCreatedDate(notification.getCreatedDate());
            updatedNotification.setRead(notification.isRead());

            return notificationRepository.save(updatedNotification);
        }

        return null;
    }

    public void deleteNotification(Long id) {
        notificationRepository.deleteById(id);
    }
}