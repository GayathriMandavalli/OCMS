package com.example.ocms.service;

import com.example.ocms.model.Instructor;
import com.example.ocms.repository.InstructorRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InstructorService {

    private final InstructorRepository instructorRepository;

    public InstructorService(InstructorRepository instructorRepository) {
        this.instructorRepository = instructorRepository;
    }

    public Instructor createInstructor(Instructor instructor) {
        return instructorRepository.save(instructor);
    }

    public List<Instructor> getAllInstructors() {
        return instructorRepository.findAll();
    }

    public Optional<Instructor> getInstructorById(Long id) {
        return instructorRepository.findById(id);
    }

    public Instructor updateInstructor(Long id, Instructor instructor) {
        Optional<Instructor> existingInstructor = instructorRepository.findById(id);

        if (existingInstructor.isPresent()) {
            Instructor updatedInstructor = existingInstructor.get();

            updatedInstructor.setName(instructor.getName());
            updatedInstructor.setEmail(instructor.getEmail());
            updatedInstructor.setContact(instructor.getContact());

            return instructorRepository.save(updatedInstructor);
        }

        return null;
    }

    public void deleteInstructor(Long id) {
        instructorRepository.deleteById(id);
    }
}