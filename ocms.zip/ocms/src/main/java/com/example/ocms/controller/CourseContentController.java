package com.example.ocms.controller;

import com.example.ocms.model.CourseContent;
import com.example.ocms.service.CourseContentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course-content")
public class CourseContentController {

    private final CourseContentService courseContentService;

    public CourseContentController(CourseContentService courseContentService) {
        this.courseContentService = courseContentService;
    }

    @PostMapping
    public CourseContent createContent(@RequestBody CourseContent content) {
        return courseContentService.createContent(content);
    }

    @GetMapping
    public List<CourseContent> getAllContent() {
        return courseContentService.getAllContent();
    }

    @GetMapping("/{id}")
    public ResponseEntity<CourseContent> getContentById(@PathVariable Long id) {
        return courseContentService.getContentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<CourseContent> updateContent(
            @PathVariable Long id,
            @RequestBody CourseContent content) {

        CourseContent updatedContent =
                courseContentService.updateContent(id, content);

        if (updatedContent != null) {
            return ResponseEntity.ok(updatedContent);
        }

        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteContent(@PathVariable Long id) {
        courseContentService.deleteContent(id);
        return ResponseEntity.noContent().build();
    }
}