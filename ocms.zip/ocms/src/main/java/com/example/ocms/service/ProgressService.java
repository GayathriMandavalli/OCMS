package com.example.ocms.service;

import com.example.ocms.model.Progress;
import com.example.ocms.repository.ProgressRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProgressService {

    private final ProgressRepository progressRepository;

    public ProgressService(ProgressRepository progressRepository) {
        this.progressRepository = progressRepository;
    }

    public Progress createProgress(Progress progress) {
        return progressRepository.save(progress);
    }

    public List<Progress> getAllProgress() {
        return progressRepository.findAll();
    }

    public Optional<Progress> getProgressById(Long id) {
        return progressRepository.findById(id);
    }

    public Progress updateProgress(Long id, Progress progress) {
        Optional<Progress> existingProgress =
                progressRepository.findById(id);

        if (existingProgress.isPresent()) {
            Progress updatedProgress = existingProgress.get();

            updatedProgress.setStudentId(progress.getStudentId());
            updatedProgress.setCourseId(progress.getCourseId());
            updatedProgress.setProgressPercentage(
                    progress.getProgressPercentage());
            updatedProgress.setStatus(progress.getStatus());

            return progressRepository.save(updatedProgress);
        }

        return null;
    }

    public void deleteProgress(Long id) {
        progressRepository.deleteById(id);
    }
}