// Builds the sidebar on every page so the menu only has to be written once.
(function () {
    var items = [
        { key: "dashboard", label: "Dashboard", href: "index.html" },
        { group: "People" },
        { key: "students", label: "Students", href: "students.html" },
        { key: "instructors", label: "Instructors", href: "instructors.html" },
        { key: "users", label: "Users", href: "users.html" },
        { group: "Learning" },
        { key: "courses", label: "Courses", href: "courses.html" },
        { key: "course-content", label: "Course content", href: "course-content.html" },
        { key: "enrollments", label: "Enrollments", href: "enrollments.html" },
        { key: "progress", label: "Progress", href: "progress.html" },
        { group: "Communication" },
        { key: "notifications", label: "Notifications", href: "notifications.html" }
    ];
    var active = document.body.getAttribute("data-page");
    var html = "<h2 class='brand'>OCMS</h2><p class='subtitle'>Online Course Management</p><nav>";
    items.forEach(function (item) {
        if (item.group) {
            html += "<span class='nav-group'>" + item.group + "</span>";
        } else {
            html += "<a href='" + item.href + "'" + (item.key === active ? " class='active'" : "") + ">" + item.label + "</a>";
        }
    });
    html += "</nav>";
    var sidebar = document.getElementById("sidebar");
    if (sidebar) { sidebar.innerHTML = html; }
})();
