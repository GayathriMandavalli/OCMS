// Loads every list from the REST API and shows totals and summaries.
(function () {
    document.getElementById("today").textContent = new Date().toLocaleDateString("en-IN", {
        weekday: "long", day: "numeric", month: "long", year: "numeric"
    });

    function byId(list) {
        var map = {};
        list.forEach(function (item) { map[item.id] = item; });
        return map;
    }
    function set(id, value) { document.getElementById(id).textContent = value; }
    function html(id, value) { document.getElementById(id).innerHTML = value; }
    function emptyRow(cols, text) { return "<tr><td colspan='" + cols + "' class='empty'>" + text + "</td></tr>"; }
    function badge(text) { return "<span class='badge badge-" + Util.slug(text) + "'>" + Util.esc(text) + "</span>"; }
    function isRead(n) { return n.read !== undefined ? n.read : n.isRead; }

    async function load() {
        try {
            var data = await Promise.all([
                Api.get("/api/students"), Api.get("/api/instructors"), Api.get("/api/courses"),
                Api.get("/api/course-content"), Api.get("/api/enrollments"), Api.get("/api/progress"),
                Api.get("/api/users"), Api.get("/api/notifications")
            ]);
            var students = data[0], instructors = data[1], courses = data[2], content = data[3],
                enrollments = data[4], progress = data[5], users = data[6], notifications = data[7];

            set("cStudents", students.length);
            set("cInstructors", instructors.length);
            set("cCourses", courses.length);
            set("cContent", content.length);
            set("cEnrollments", enrollments.length);
            set("cUsers", users.length);
            set("cUnread", notifications.filter(function (n) { return !isRead(n); }).length);
            var avg = progress.length
                ? Math.round(progress.reduce(function (sum, p) { return sum + (p.progressPercentage || 0); }, 0) / progress.length)
                : 0;
            set("cProgress", avg + "%");

            var s = byId(students), c = byId(courses), i = byId(instructors);

            // recent enrollments (newest 5)
            var recent = enrollments.slice().sort(function (a, b) { return b.id - a.id; }).slice(0, 5);
            html("recentEnrollments", recent.length ? recent.map(function (e) {
                return "<tr><td>" + Util.esc(s[e.studentId] ? s[e.studentId].name : "#" + e.studentId) + "</td>"
                    + "<td>" + Util.esc(c[e.courseId] ? c[e.courseId].title : "#" + e.courseId) + "</td>"
                    + "<td>" + Util.esc(Util.fmtDate(e.enrollmentDate)) + "</td>"
                    + "<td>" + badge(e.status || "") + "</td></tr>";
            }).join("") : emptyRow(4, "No enrollments yet."));

            // progress list (latest 5)
            var latest = progress.slice().sort(function (a, b) { return b.id - a.id; }).slice(0, 5);
            html("progressList", latest.length ? latest.map(function (p) {
                var pct = Math.max(0, Math.min(100, p.progressPercentage || 0));
                return "<tr><td>" + Util.esc(s[p.studentId] ? s[p.studentId].name : "#" + p.studentId) + "</td>"
                    + "<td>" + Util.esc(c[p.courseId] ? c[p.courseId].title : "#" + p.courseId) + "</td>"
                    + "<td><div class='bar'><span style='width:" + pct + "%'></span></div> <small>" + pct + "%</small></td></tr>";
            }).join("") : emptyRow(3, "No progress recorded yet."));

            // course overview
            html("courseOverview", courses.length ? courses.map(function (course) {
                var enrolled = enrollments.filter(function (e) { return e.courseId === course.id; }).length;
                var items = content.filter(function (x) { return x.courseId === course.id; }).length;
                return "<tr><td>" + Util.esc(course.title) + "</td>"
                    + "<td>" + Util.esc(course.category || "") + "</td>"
                    + "<td>" + Util.esc(i[course.instructorId] ? i[course.instructorId].name : "") + "</td>"
                    + "<td>" + items + "</td><td>" + enrolled + "</td></tr>";
            }).join("") : emptyRow(5, "No courses yet. Add instructors first, then create courses."));
        } catch (error) {
            Util.flash("Could not reach the backend. Check that the Spring Boot application is running and connected to MySQL. (" + error.message + ")", "error");
            ["recentEnrollments", "progressList", "courseOverview"].forEach(function (id) {
                html(id, emptyRow(5, "No data"));
            });
        }
    }
    load();
})();
