// Small helper around fetch() for the OCMS REST API, plus a few shared utilities.
const Api = {
    async request(method, url, body) {
        const options = { method: method, headers: { "Accept": "application/json" } };
        if (body !== undefined) {
            options.headers["Content-Type"] = "application/json";
            options.body = JSON.stringify(body);
        }
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(method + " " + url + " failed with status " + response.status);
        }
        if (response.status === 204) {
            return null;
        }
        const text = await response.text();
        return text ? JSON.parse(text) : null;
    },
    get(url) { return this.request("GET", url); },
    post(url, body) { return this.request("POST", url, body); },
    put(url, body) { return this.request("PUT", url, body); },
    del(url) { return this.request("DELETE", url); }
};

const Util = {
    /** Escapes text so it can be placed safely inside HTML. */
    esc(value) {
        return String(value === null || value === undefined ? "" : value)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    },
    pad(n) { return String(n).padStart(2, "0"); },
    today() {
        const d = new Date();
        return d.getFullYear() + "-" + Util.pad(d.getMonth() + 1) + "-" + Util.pad(d.getDate());
    },
    nowLocal() {
        const d = new Date();
        return Util.today() + "T" + Util.pad(d.getHours()) + ":" + Util.pad(d.getMinutes());
    },
    /** Accepts "2026-10-25", "2026-10-25T10:30:00" or [2026,10,25,...] and returns a Date (or null). */
    toDate(value) {
        if (value === null || value === undefined || value === "") { return null; }
        if (Array.isArray(value)) {
            return new Date(value[0], value[1] - 1, value[2], value[3] || 0, value[4] || 0, value[5] || 0);
        }
        const d = new Date(value);
        return isNaN(d.getTime()) ? null : d;
    },
    fmtDate(value) {
        const d = Util.toDate(value);
        return d ? d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "";
    },
    fmtDateTime(value) {
        const d = Util.toDate(value);
        return d ? d.toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "";
    },
    /** Value for <input type="date"> */
    inputDate(value) {
        const d = Util.toDate(value);
        return d ? d.getFullYear() + "-" + Util.pad(d.getMonth() + 1) + "-" + Util.pad(d.getDate()) : "";
    },
    /** Value for <input type="datetime-local"> */
    inputDateTime(value) {
        const d = Util.toDate(value);
        return d ? Util.inputDate(d) + "T" + Util.pad(d.getHours()) + ":" + Util.pad(d.getMinutes()) : "";
    },
    slug(value) {
        return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    },
    /** Only http/https links are clickable; anything else is shown as plain text. */
    isSafeUrl(value) {
        return /^https?:\/\//i.test(String(value || "").trim());
    },
    flash(message, type) {
        const box = document.getElementById("flash");
        if (!box) { return; }
        box.innerHTML = "<div class='flash flash-" + (type || "success") + "'>" + Util.esc(message) + "</div>";
        clearTimeout(Util._flashTimer);
        if ((type || "success") === "success") {
            Util._flashTimer = setTimeout(function () { box.innerHTML = ""; }, 4000);
        }
    }
};
