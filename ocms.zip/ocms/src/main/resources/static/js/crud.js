// Generic list / add / edit / delete screen for one REST resource.
// Each page calls CRUD.init({...}) with the endpoint and the list of fields.
const CRUD = (function () {
    var cfg = null;
    var rows = [];
    var lookups = {};      // field name -> array of records for lookup fields
    var editingId = null;

    // ------------------------------------------------------------ start up
    function init(config) {
        cfg = config;
        document.getElementById("addBtn").addEventListener("click", function () { openForm(null); });
        document.getElementById("search").addEventListener("input", render);
        document.getElementById("cancelBtn").addEventListener("click", closeForm);
        document.getElementById("closeX").addEventListener("click", closeForm);
        document.getElementById("recordForm").addEventListener("submit", onSubmit);
        buildHead();
        load();
    }

    async function load() {
        setBody("<tr><td colspan='" + (cfg.fields.length + 2) + "' class='empty'>Loading...</td></tr>");
        try {
            var lookupFields = cfg.fields.filter(function (f) { return f.type === "lookup"; });
            var results = await Promise.all([Api.get(cfg.endpoint)].concat(
                lookupFields.map(function (f) { return Api.get(f.endpoint); })));
            rows = results[0] || [];
            lookupFields.forEach(function (f, i) { lookups[f.name] = results[i + 1] || []; });
            render();
        } catch (error) {
            setBody("<tr><td colspan='" + (cfg.fields.length + 2) + "' class='empty'>Could not load data. "
                + "Check that the Spring Boot application is running and connected to MySQL.</td></tr>");
            Util.flash(error.message, "error");
        }
    }

    // ------------------------------------------------------------ table
    function buildHead() {
        var html = "<tr><th>#</th>";
        cfg.fields.forEach(function (f) { html += "<th>" + Util.esc(f.label) + "</th>"; });
        html += "<th class='right'>Actions</th></tr>";
        document.getElementById("thead").innerHTML = html;
    }

    function setBody(html) { document.getElementById("tbody").innerHTML = html; }

    function lookupLabel(field, id) {
        var list = lookups[field.name] || [];
        for (var i = 0; i < list.length; i++) {
            if (String(list[i].id) === String(id)) { return list[i][field.labelField]; }
        }
        return id === null || id === undefined || id === "" ? "" : "#" + id + " (deleted)";
    }

    function rawValue(row, field) {
        if (field.name === "read") { return row.read !== undefined ? row.read : row.isRead; }
        return row[field.name];
    }

    /** Plain-text version of a cell; used for searching. */
    function textValue(row, field) {
        var v = rawValue(row, field);
        switch (field.type) {
            case "lookup": return lookupLabel(field, v);
            case "date": return Util.fmtDate(v);
            case "datetime-local": return Util.fmtDateTime(v);
            case "checkbox": return v ? "Yes" : "No";
            case "password": return "";
            default: return v === null || v === undefined ? "" : String(v);
        }
    }

    function cellHtml(row, field) {
        var text = textValue(row, field);
        var v = rawValue(row, field);
        if (field.type === "password") { return "<span class='muted'>&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;</span>"; }
        if (field.type === "checkbox") {
            return v ? "<span class='badge badge-read'>Yes</span>" : "<span class='badge badge-unread'>No</span>";
        }
        if (field.bar) {
            var pct = Math.max(0, Math.min(100, Number(v) || 0));
            return "<div class='bar' title='" + pct + "%'><span style='width:" + pct + "%'></span></div> <small>" + pct + "%</small>";
        }
        if (field.badges && text) {
            return "<span class='badge badge-" + Util.slug(text) + "'>" + Util.esc(text) + "</span>";
        }
        if (field.type === "url" && Util.isSafeUrl(text)) {
            return "<a href='" + Util.esc(text) + "' target='_blank' rel='noopener noreferrer'>Open link</a>";
        }
        if (field.type === "textarea") {
            return "<span class='clip' title='" + Util.esc(text) + "'>" + Util.esc(text) + "</span>";
        }
        return Util.esc(text);
    }

    function render() {
        var query = document.getElementById("search").value.trim().toLowerCase();
        var visible = rows.filter(function (row) {
            if (!query) { return true; }
            return cfg.fields.some(function (f) { return textValue(row, f).toLowerCase().indexOf(query) !== -1; });
        });

        document.getElementById("count").textContent = visible.length + (visible.length === 1 ? " record" : " records");

        if (visible.length === 0) {
            setBody("<tr><td colspan='" + (cfg.fields.length + 2) + "' class='empty'>"
                + (rows.length === 0
                    ? "No " + Util.esc(cfg.plural) + " yet. Use &quot;Add " + Util.esc(cfg.singular) + "&quot; to create the first one."
                    : "No " + Util.esc(cfg.plural) + " match your search.")
                + "</td></tr>");
            return;
        }

        var html = "";
        visible.forEach(function (row) {
            html += "<tr><td class='muted'>" + Util.esc(row.id) + "</td>";
            cfg.fields.forEach(function (f) { html += "<td>" + cellHtml(row, f) + "</td>"; });
            html += "<td class='actions'>";
            (cfg.extraActions || []).forEach(function (a, i) {
                if (!a.show || a.show(row)) {
                    html += "<button class='btn btn-sm btn-light' data-extra='" + i + "' data-id='" + row.id + "'>" + Util.esc(a.label) + "</button> ";
                }
            });
            html += "<button class='btn btn-sm btn-light' data-edit='" + row.id + "'>Edit</button> "
                + "<button class='btn btn-sm btn-danger' data-delete='" + row.id + "'>Delete</button></td></tr>";
        });
        setBody(html);

        var tbody = document.getElementById("tbody");
        tbody.querySelectorAll("[data-edit]").forEach(function (b) {
            b.addEventListener("click", function () { openForm(findRow(b.getAttribute("data-edit"))); });
        });
        tbody.querySelectorAll("[data-delete]").forEach(function (b) {
            b.addEventListener("click", function () { removeRow(findRow(b.getAttribute("data-delete"))); });
        });
        tbody.querySelectorAll("[data-extra]").forEach(function (b) {
            b.addEventListener("click", function () {
                var action = cfg.extraActions[Number(b.getAttribute("data-extra"))];
                runExtra(action, findRow(b.getAttribute("data-id")));
            });
        });
    }

    function findRow(id) {
        for (var i = 0; i < rows.length; i++) {
            if (String(rows[i].id) === String(id)) { return rows[i]; }
        }
        return null;
    }

    // ------------------------------------------------------------ form
    function openForm(row) {
        editingId = row ? row.id : null;
        document.getElementById("formTitle").textContent = (row ? "Edit " : "Add ") + cfg.singular;
        var box = document.getElementById("formFields");
        box.innerHTML = "";

        cfg.fields.forEach(function (f) {
            var group = document.createElement("div");
            group.className = "form-group" + (f.type === "textarea" ? " full" : "");

            var label = document.createElement("label");
            label.setAttribute("for", "f_" + f.name);
            label.textContent = f.label + (f.required ? " *" : "");
            group.appendChild(label);

            var input = buildInput(f);
            var current = row ? rawValue(row, f) : (typeof f.default === "function" ? f.default() : f.default);
            setInputValue(input, f, current);
            group.appendChild(input);

            var error = document.createElement("span");
            error.className = "field-error";
            error.id = "e_" + f.name;
            group.appendChild(error);

            if (f.type === "lookup" && (lookups[f.name] || []).length === 0) {
                var note = document.createElement("span");
                note.className = "hint";
                note.textContent = "No " + f.labelPlural + " exist yet. Add one first.";
                group.appendChild(note);
            }
            box.appendChild(group);
        });

        var dialog = document.getElementById("modal");
        if (typeof dialog.showModal === "function") { dialog.showModal(); } else { dialog.setAttribute("open", ""); }
        var first = box.querySelector("input, select, textarea");
        if (first) { first.focus(); }
    }

    function closeForm() {
        var dialog = document.getElementById("modal");
        if (typeof dialog.close === "function") { dialog.close(); } else { dialog.removeAttribute("open"); }
    }

    function buildInput(f) {
        var el;
        if (f.type === "textarea") {
            el = document.createElement("textarea");
            el.rows = 3;
        } else if (f.type === "select" || f.type === "lookup") {
            el = document.createElement("select");
            var blank = document.createElement("option");
            blank.value = "";
            blank.textContent = "Select " + (f.labelSingular || f.label.toLowerCase());
            el.appendChild(blank);
            var options = f.type === "select"
                ? f.options.map(function (o) { return { value: o, text: o }; })
                : (lookups[f.name] || []).map(function (r) { return { value: r.id, text: r[f.labelField] + " (#" + r.id + ")" }; });
            options.forEach(function (o) {
                var opt = document.createElement("option");
                opt.value = o.value;
                opt.textContent = o.text;
                el.appendChild(opt);
            });
        } else {
            el = document.createElement("input");
            el.type = f.type === "url" ? "text" : f.type;
            if (f.min !== undefined) { el.min = f.min; }
            if (f.max !== undefined) { el.max = f.max; }
            if (f.placeholder) { el.placeholder = f.placeholder; }
            if (f.type === "password") { el.autocomplete = "new-password"; }
        }
        el.id = "f_" + f.name;
        el.name = f.name;
        return el;
    }

    function setInputValue(input, f, value) {
        if (f.type === "checkbox") { input.checked = !!value; return; }
        if (value === null || value === undefined) { input.value = ""; return; }
        if (f.type === "date") { input.value = Util.inputDate(value); return; }
        if (f.type === "datetime-local") { input.value = Util.inputDateTime(value); return; }
        input.value = value;
    }

    function readValues() {
        var values = {};
        cfg.fields.forEach(function (f) {
            var input = document.getElementById("f_" + f.name);
            var raw = f.type === "checkbox" ? input.checked : input.value.trim();
            if (f.type === "checkbox") { values[f.name] = raw; return; }
            if (raw === "") { values[f.name] = (f.type === "text" || f.type === "email" || f.type === "tel"
                || f.type === "textarea" || f.type === "url" || f.type === "password") ? "" : null; return; }
            if (f.type === "number" || f.type === "lookup") { values[f.name] = Number(raw); return; }
            values[f.name] = raw;
        });
        return values;
    }

    function validate(values) {
        var errors = {};
        cfg.fields.forEach(function (f) {
            var v = values[f.name];
            var empty = v === "" || v === null || v === undefined;
            if (f.required && f.type !== "checkbox" && empty) { errors[f.name] = f.label + " is required"; return; }
            if (empty) { return; }
            if (f.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { errors[f.name] = "Enter a valid email address"; }
            if (f.type === "tel" && !/^[0-9+()\-\s]{7,20}$/.test(v)) { errors[f.name] = "Enter a valid phone number"; }
            if (f.type === "number") {
                if (f.min !== undefined && v < f.min) { errors[f.name] = f.label + " must be at least " + f.min; }
                if (f.max !== undefined && v > f.max) { errors[f.name] = f.label + " cannot be more than " + f.max; }
            }
            if (f.type === "url" && !Util.isSafeUrl(v)) { errors[f.name] = "Enter a link starting with http:// or https://"; }
        });
        if (Object.keys(errors).length === 0 && cfg.validate) {
            var custom = cfg.validate(values, rows, editingId);
            if (custom) { errors[custom.field] = custom.message; }
        }
        return errors;
    }

    async function onSubmit(event) {
        event.preventDefault();
        var values = readValues();
        var errors = validate(values);

        cfg.fields.forEach(function (f) {
            document.getElementById("e_" + f.name).textContent = errors[f.name] || "";
        });
        if (Object.keys(errors).length > 0) { return; }

        var button = document.getElementById("saveBtn");
        button.disabled = true;
        try {
            if (editingId === null) {
                await Api.post(cfg.endpoint, values);
                Util.flash(cap(cfg.singular) + " added.");
            } else {
                await Api.put(cfg.endpoint + "/" + editingId, values);
                Util.flash(cap(cfg.singular) + " updated.");
            }
            closeForm();
            await load();
        } catch (error) {
            Util.flash("Could not save: " + error.message, "error");
        } finally {
            button.disabled = false;
        }
    }

    async function removeRow(row) {
        if (!row) { return; }
        if (!window.confirm("Delete this " + cfg.singular + " (#" + row.id + ")? This cannot be undone.")) { return; }
        try {
            await Api.del(cfg.endpoint + "/" + row.id);
            Util.flash(cap(cfg.singular) + " deleted.");
            await load();
        } catch (error) {
            Util.flash("Could not delete: " + error.message, "error");
        }
    }

    async function runExtra(action, row) {
        if (!row) { return; }
        try {
            var updated = Object.assign({}, row);
            if (row.read === undefined && row.isRead !== undefined) { updated.read = row.isRead; }
            action.apply(updated);
            await Api.put(cfg.endpoint + "/" + row.id, updated);
            Util.flash(action.done || "Updated.");
            await load();
        } catch (error) {
            Util.flash("Could not update: " + error.message, "error");
        }
    }

    function cap(text) { return text.charAt(0).toUpperCase() + text.slice(1); }

    return { init: init };
})();
