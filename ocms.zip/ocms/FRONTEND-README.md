# OCMS frontend

The frontend is plain HTML, CSS and JavaScript in `src/main/resources/static`.
Spring Boot serves these files automatically, and the pages call your existing REST API (`/api/...`).
No backend code, dependency or `pom.xml` change was needed.

## Run
1. Start MySQL (database `ocms`, user and password as in `application.properties`).
2. Run `OcmsApplication` in IntelliJ.
3. Open http://localhost:8080

## Pages
| Page | File | API used |
|---|---|---|
| Dashboard (totals, recent enrollments, progress, course overview) | index.html | all endpoints |
| Students | students.html | /api/students |
| Instructors | instructors.html | /api/instructors |
| Users | users.html | /api/users |
| Courses | courses.html | /api/courses (+ /api/instructors) |
| Course content | course-content.html | /api/course-content (+ /api/courses) |
| Enrollments | enrollments.html | /api/enrollments (+ students, courses) |
| Progress | progress.html | /api/progress (+ students, courses) |
| Notifications | notifications.html | /api/notifications (+ /api/users) |

Every list page has: search, add, edit, delete, form validation, and names instead of raw IDs for related records.

## How it works (viva notes)
- `js/api.js` wraps `fetch()` (GET, POST, PUT, DELETE) and has small helpers (date formatting, HTML escaping).
- `js/crud.js` is one reusable list/add/edit/delete screen. Each page only describes its fields:
  `CRUD.init({ endpoint: "/api/students", fields: [...] })`.
- `js/layout.js` builds the sidebar on every page. `js/dashboard.js` powers the dashboard.
- Flow: click Add -> form validated in the browser -> `POST /api/students` -> controller -> service -> repository -> MySQL -> table reloads.

## Extra rules added in the browser
- Enrollments: the same student cannot be enrolled twice in the same course.
- Progress: 0-100 only; Completed must be 100%; Not Started must be 0%; one record per student and course.
- Course content: only http/https links are clickable.
